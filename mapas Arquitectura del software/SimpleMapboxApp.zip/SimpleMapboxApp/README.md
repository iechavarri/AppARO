# SimpleMap
Mapbox Map in an Android App


<img src="https://raw.githubusercontent.com/bleege/SimpleMap/master/screenshot.png" width="540" height="960">
